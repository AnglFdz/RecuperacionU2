import React from 'react'

function UserLayout() {
  return (
    <>
      <section className='pt-4 px-3 flex flex-col'>
        <div>
          <h1>Usuarios</h1>
        </div>
        <div>
          TABLA DE USUARIOS
        </div>
      </section>
    </>
  )
}

export default UserLayout