package mx.edu.utez.firstapp.controllers.user;

public class UserController {
}
